MOV [BX],1
