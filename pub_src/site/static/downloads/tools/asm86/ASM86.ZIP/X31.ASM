ADD [BX],[DI]
