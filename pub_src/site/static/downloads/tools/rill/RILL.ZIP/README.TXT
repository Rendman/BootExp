THE BOOTSTRAP PROJECT - RILL
A practical course in small-system software

The compiler construction: RILL0 -> RILLBOOT compiler seed -> RILL.
The preceding native ladder is BOOTASM -> ASM0 -> ASM1 -> ASM86
-> streaming IR86. Use the same DOS 3.10 and period BASIC workbench.
All files here are ASCII/CRLF/8.3 source. No executable is supplied.

ASM86.ASM and IRWIDE.ASM: unchanged native prerequisite sources.
Preserve their tested executables as ASMAKEEP.COM and IWKEEP.COM.
VIEW.BAS inspects bytes; CHECK.BAT forwards filename arguments.
RC01 through RC43: complete construction checkpoint sources.
T-prefixed and X-prefixed RIL files: exact acceptance/rejection inputs.
RILL.RIL: complete compiler source, identical to RC43.RIL.
Early checkpoints are executable helper diagnostics. An emitted text
fragment is inspected as text; it is not a complete compiler result.
Require each fresh OK and PASS before copying the next result.

Begin with the completed RILLBOOT collection and its RILLBOOT.COM.
RILLBOOT.IR is its unchanged source, built with IWKEEP and ASMAKEEP.
Compile RILL sources with RILLBOOT, then IWKEEP and ASMAKEEP.
RC43 already supports 64 locals. Preserve its seed-built executable
as RBOOT.COM and its source as RILL.RIL. RBOOT compiles that same
source to establish R0 using the RILL compiler's own 64-slot frames.
R0 compiles that same source to R1, then R1 to R2; both match R0 exactly.
TLOCAL.RIL, XLOCAL.RIL and TSCOPE.RIL check local/frame bounds and reuse.
ERECUR.RIL, EHEAP.RIL and ECOPY.RIL are complete compiler examples.
After both compiler self-builds match, continue with Rebuilding Our
Tools in RILL. Its TOOLCHN.ZIP supplies IR86.RIL, ASM86.RIL, and
TMAKE.BAT for the complete three-tool builds and comparisons.

Default work names are SOURCE.RIL/RESULT.IR, SOURCE.IR/RESULT.ASM and
SOURCE.ASM/RESULT.COM files in a hard-disk directory. Keep each builder
separately named. Inspect existing temporary/backup files before a run.
Source rejection preserves accepted output; failed publication can
leave recovery files. Require a new successful status before using it.
The complete RILL language has 24-character folded names, 512 global
or procedure symbols, sixteen parameters and sixty-four live local words, lexical
scopes, recursive calls, byte buffers, strings and opaque file/block
services. RILLBOOT accepts the subset used to implement that compiler.
Consult each compiler's own reference for accepted syntax and bounds.

COMMAND-LINE FILENAMES
From ASM1 onward, supply input and output filenames on the command
line: CHECK tool INPUT.EXT OUTPUT.EXT. No arguments select the
default work names. Use unquoted 8.3 filenames in the current directory;
paths and switches are not accepted. Input, output, temporary and backup
names must be distinct. LINK86 takes two object names then the result;
EDIT86 takes one document name and saves that same document.
