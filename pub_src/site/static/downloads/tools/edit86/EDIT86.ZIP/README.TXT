THE BOOTSTRAP PROJECT - EDIT86
Building Our Screen Editor

Begin after the completed RILL-written toolchain. Preserve its R0.COM,
I0.COM and A0.COM and their matching RILL.RIL/IR86.RIL/ASM86.RIL sources.
Use the workbench and articles for the exact edits and build reports.
No compiler, translator, assembler or editor executable is supplied.

Build RILLED.RIL with R0/I0/A0 and save RESULT.COM as RILLED.COM.
Build IRED.RIL with R0/I0/A0 and save RESULT.COM as IRED.COM.
The new compiler and translator retain the established languages and
add only editor services. IRED reads EDITRT.ASM from its work directory
and appends that authored target binding to its assembly output.
S02.ASM is empty. S03.ASM through S07.ASM are continuing binding stages.
S03.RIL through S07.RIL are small service checks, not editor versions.
P01/Q01 check the compiler; P02/Q02 check the translator. P01.IR is
compiler-produced text for exact inspection, not machine code.

Use RILLED, IRED and A0 for E08.RIL through E20.RIL. Copy S07.ASM to
EDITRT.ASM before translating them. Copy each source to SOURCE.RIL,
require the fresh compiler OK and CHECK PASS, copy RESULT.IR to
SOURCE.IR, require translator OK and PASS, copy RESULT.ASM to
SOURCE.ASM, require assembler OK and PASS, then preserve RESULT.COM
under its checkpoint name. Never trust a stale result after failure.
E20.RIL and EDIT86.RIL are identical. Preserve E20.COM as EDIT86.COM.

Early document checks use DOS status and byte comparisons, without
extra display routines. T10.TXT through T20.TXT are CR/LF fixtures;
T14 has a literal tab. The final source grows the same paired-position,
page, reader, writer and gap routines into the full screen editor.
Use VIEW.BAS for lengths and bytes; CHECK.BAT makes status visible.

EDIT86 edits fixed EDIT.TXT. Select a source with COPY, preserve a
separately named accepted original, edit/save, then copy back only
after Saved and a clean exit. Navigation changes memory only. The
whole document and its insertion gap share eight 32768-byte blocks.
Files up to 262144 bytes are accepted; a full buffer needs a deletion
before insertion. There is no imposed line length or line count.
A separate 16384-byte ring retains the newest 2048 edits, with no redo.
The main 64 KiB plus text and undo requests total 336 KiB, before DOS,
environment and memory control overhead. All requests are checked.
Use the reference 640 KiB machine and an 80-column mode 3 or 7 screen.

Arrows/Home/End/Page Up/Page Down navigate. F6/F7 select document
start/end. Enter inserts CR/LF, Tab inserts a literal tab. Delete and
Backspace keep CR/LF paired. F2 (Control-S) saves, F3 finds literal
case-sensitive text up to 64 printable characters, F5 finds next,
F4 (Control-Z) undoes, F10 (Control-Q) quits. Unsaved quit asks S to
save, Q to discard or Escape to cancel. Search does not wrap.
Control/high bytes display as dots but round-trip unchanged. Long
lines scroll horizontally and may be slow; they are not truncated.

EDIT.TMP and EDIT.BAK are reserved recovery names. Existing copies
block entry/saving. Save writes and closes the temporary, backs up
the old document, publishes the temporary, then removes the backup.
A failed publication attempts restoration. Failed restoration or
backup deletion retains recovery material. Inspect and copy it to
safe names before retrying. This is not a power-loss guarantee.
A clean quit after deliberate discard does not imply a prior save.

All members are source-only ASCII with DOS CR/LF and 8.3 filenames.
Keep the earlier source collections to reproduce every builder.

COMMAND-LINE FILENAMES
From ASM1 onward, supply input and output filenames on the command
line: CHECK tool INPUT.EXT OUTPUT.EXT. No arguments select the
default work names. Use unquoted 8.3 filenames in the current directory;
paths and switches are not accepted. Input, output, temporary and backup
names must be distinct. LINK86 takes two object names then the result;
EDIT86 takes one document name and saves that same document.
