BOOTSTRAP EXPERIMENT - RILLBOOT

Read the matching workbench and construction articles in order.
Use your own DOS 3.10 and period BASIC interpreter.
VIEW.BAS inspects lengths and bytes. CHECK.BAT checks program status.
Require each fresh OK and PASS before copying a result to the next tool.
Sources are ASCII with DOS line endings and 8.3 filenames.
No executable, interpreter, or outside compiler is included.

Begin by copying the completed small RILL0.IR to RB01.IR.
RB01.IR through RB12.IR extend that working compiler.
RILLBOOT.IR is identical to RB12.IR.
Use IRKEEP and ASMAKEEP. Preserve RILLBOOT.COM for the RILL compiler.
Every continuation accepts the preceding language subset.

Early helper output can be an incomplete fragment; inspect its bytes.
Execute only programs identified as complete in their article.
Source rejection preserves accepted output. A failed publication may
leave temporary or backup files; inspect those before a new run.

COMMAND-LINE FILENAMES
From ASM1 onward, supply input and output filenames on the command
line: CHECK tool INPUT.EXT OUTPUT.EXT. No arguments select the
default work names. Use unquoted 8.3 filenames in the current directory;
paths and switches are not accepted. Input, output, temporary and backup
names must be distinct. LINK86 takes two object names then the result;
EDIT86 takes one document name and saves that same document.
